-- Les réglages se modifient ici, sans toucher à la logique du loueur.
Config = {}
Config.Framework = 'auto' -- 'auto', 'esx', 'qbcore', 'qbox', 'standalone'
Config.Accounts = { esx = 'money', qbcore = 'cash', qbox = 'cash' }

Config.Merchant = {
    [1] = {
        model = 'ig_trafficwarden',
        coords = vector4(-1034.55, -2733.62, 20.17, 150.0),
        label = 'Michel'
    }
}
Config.RentalMerchant = Config.Merchant[1] or Config.Merchant

-- Point commun utilisé si un véhicule possède spawn = nil.
-- vector4(X, Y, Z, orientation en degrés).
Config.Spawn = vector4(-1030.20, -2730.30, 20.15, 240.0)
Config.InteractDistance = 2.0
Config.ServerDistance = 3.0
Config.InteractControl = 38 -- Touche E.
Config.InteractPrompt = 'Appuie sur ~INPUT_CONTEXT~ pour louer un véhicule.'
Config.WarningSeconds = 120
Config.ExpiryGraceSeconds = 120
Config.SpawnClearance = 2.5
Config.SpawnTimeoutMs = 5000
Config.ModelTimeoutMs = 10000

-- Trois véhicules natifs GTA V. Aucun modèle additionnel nécessaire.
Config.Vehicles = {
    bmx = {
        label = 'BMX',
        model = 'bmx',
        vehicleType = 'bike',
        enabled = true,
        spawn = vector4(-1030.20, -2730.30, 20.15, 240.0),
        description = 'Un vélo agile pour explorer la ville.',
        prices = { [30] = 500, [60] = 1000 }
    },
    panto = {
        label = 'Panto',
        model = 'panto',
        vehicleType = 'automobile',
        enabled = true,
        spawn = vector4(-1030.20, -2730.30, 20.15, 240.0),
        description = 'Une petite citadine pratique pour tes déplacements.',
        prices = { [30] = 300, [60] = 600 }
    },
    faggio = {
        label = 'Faggio',
        model = 'faggio2',
        vehicleType = 'bike',
        enabled = true,
        spawn = vector4(-1030.20, -2730.30, 20.15, 240.0),
        description = 'Un scooter pour circuler tranquillement en ville.',
        prices = { [30] = 750, [60] = 1500 }
    }
}
Config.VehicleOrder = { 'bmx', 'panto', 'faggio' }

Config.Timer = {
    enabled = true,
    onlyInRentedVehicle = true, -- Le compteur disparaît à la descente.
    refreshMs = 200
}
Config.Performance = {
    farDistance = 30.0,
    farWaitMs = 1000,
    nearWaitMs = 250,
    menuWaitMs = 200,
    serverTickMs = 1000,
    requestCooldownMs = 1000
}
Config.NotificationsDurationMs = 5000
Config.NotificationLabel = 'LOCATION'
Config.Keys = 'auto' -- 'auto', 'none', 'qb', 'qbox', 'custom'.
Config.Fuel = { level = 100.0, resource = '', export = 'SetFuel' }
-- resource vide : carburant natif. Sinon, renseigner une ressource compatible.
