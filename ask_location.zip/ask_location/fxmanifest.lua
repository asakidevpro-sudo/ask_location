fx_version 'cerulean'
game 'gta5'
author 'Location'
description 'Loueur de mobilité - bridge ESX / QBCore / Qbox / standalone'
version '0.2.0'
shared_script 'config.lua'
client_script 'client.lua'
server_scripts { 'server/standalone.lua', 'server/bridge.lua', 'server/main.lua' }
ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css', 'html/app.js' }
dependency '/onesync'
