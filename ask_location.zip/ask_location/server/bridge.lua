-- Adaptateur serveur : toutes les dépendances de framework restent ici.
Bridge = {}
local selected, core, initialized, lastError = nil, nil, false, nil
local resources = { esx = 'es_extended', qbcore = 'qb-core', qbox = 'qbx_core' }
local knownResources = { es_extended = true, ['qb-core'] = true, qbx_core = true }
local unavailable = 'Le service de location est temporairement indisponible.'
local function report(reason)
    if reason ~= lastError then print('[Location] ' .. tostring(reason)) lastError = reason end
end
local function resolve()
    if initialized then return selected ~= nil end
    initialized, selected, core = true, nil, nil
    local choice = Config.Framework
    if choice == 'qb' then choice = 'qbcore' end
    if choice == 'qbx' then choice = 'qbox' end
    if choice == 'auto' then
        local esx = GetResourceState('es_extended') == 'started'
        local qbox = GetResourceState('qbx_core') == 'started'
        local qb = not qbox and GetResourceState('qb-core') == 'started'
        if esx and (qbox or qb) then report('Plusieurs frameworks détectés : choisir Config.Framework explicitement.') return false end
        choice = esx and 'esx' or (qbox and 'qbox' or (qb and 'qbcore' or 'standalone'))
    end
    if choice ~= 'standalone' and not resources[choice] then report('Config.Framework invalide : ' .. tostring(choice)) return false end
    if resources[choice] and GetResourceState(resources[choice]) ~= 'started' then report('Framework non démarré : ' .. resources[choice]) return false end
    local ok, result = pcall(function()
        if choice == 'esx' then return exports['es_extended']:getSharedObject() end
        if choice == 'qbcore' then return exports['qb-core']:GetCoreObject() end
        return true
    end)
    if not ok or not result then report('Initialisation du bridge impossible : ' .. tostring(result)) return false end
    selected, core, lastError = choice, result, nil
    return true
end
local function ready()
    if not resolve() then return false end
    if resources[selected] and GetResourceState(resources[selected]) ~= 'started' then
        initialized = false
        return false
    end
    return true
end
AddEventHandler('onResourceStart', function(name)
    if knownResources[name] then initialized, selected, core, lastError = false, nil, nil, nil end
end)
AddEventHandler('onResourceStop', function(name)
    if knownResources[name] then initialized, selected, core, lastError = false, nil, nil, nil end
end)
local function balance(playerId)
    if selected == 'standalone' then return Standalone.Balance(playerId) end
    if selected == 'qbox' then return exports['qbx_core']:GetMoney(playerId, Config.Accounts.qbox) end
    if selected == 'esx' then
        local player = core.GetPlayerFromId(playerId)
        local account = player and player.getAccount(Config.Accounts.esx)
        return account and account.money
    end
    local player = core.Functions.GetPlayer(playerId)
    return player and player.Functions.GetMoney(Config.Accounts.qbcore)
end
function Bridge.Balance(playerId)
    if not ready() then return nil, unavailable end
    local ok, amount, detail = pcall(balance, playerId)
    if not ok or type(amount) ~= 'number' or amount ~= amount or amount < 0 or amount == math.huge then
        report(detail or ('Compte indisponible ou erreur du bridge : ' .. tostring(amount)))
        return nil, unavailable
    end
    return amount
end
function Bridge.Charge(playerId, amount)
    if type(amount) ~= 'number' or amount <= 0 or amount % 1 ~= 0 then return false, 'Montant invalide.' end
    local money, reason = Bridge.Balance(playerId)
    if money == nil then return false, reason end
    if money < amount then return false, 'Tu n’as pas assez d’argent.' end
    local ok, paid = pcall(function()
        if selected == 'standalone' then return Standalone.Charge(playerId, amount) end
        if selected == 'qbox' then return exports['qbx_core']:RemoveMoney(playerId, Config.Accounts.qbox, amount, 'Location de véhicule') end
        if selected == 'esx' then
            local player = core.GetPlayerFromId(playerId)
            if not player then return false end
            player.removeAccountMoney(Config.Accounts.esx, amount, 'Location de véhicule')
            return true -- ESX ne renvoie pas de booléen de succès.
        end
        local player = core.Functions.GetPlayer(playerId)
        return player and player.Functions.RemoveMoney(Config.Accounts.qbcore, amount, 'Location de véhicule') == true
    end)
    if not ok then report('Erreur de paiement : ' .. tostring(paid)) return false, unavailable end
    return paid == true, 'Le paiement a été refusé.'
end
function Bridge.Identity(playerId)
    if not ready() then return nil end
    if selected == 'esx' then
        local player = core.GetPlayerFromId(playerId)
        return player and player.identifier
    elseif selected == 'qbcore' or selected == 'qbox' then
        local player
        if selected == 'qbox' then player = exports['qbx_core']:GetPlayer(playerId)
        else player = core.Functions.GetPlayer(playerId) end
        return player and player.PlayerData.citizenid
    end
    return GetPlayerIdentifierByType(playerId, 'license')
end
local function keySystem()
    if Config.Keys ~= 'auto' then return Config.Keys end
    if GetResourceState('qbx_vehiclekeys') == 'started' then return 'qbox' end
    if GetResourceState('qb-vehiclekeys') == 'started' then return 'qb' end
    return 'none'
end
function Bridge.GiveKeys(playerId, vehicle, plate)
    local system = keySystem()
    local ok, result = pcall(function()
        if system == 'qbox' then exports['qbx_vehiclekeys']:GiveKeys(playerId, vehicle, true)
        elseif system == 'qb' then exports['qb-vehiclekeys']:GiveKeys(playerId, plate)
        elseif system == 'custom' then return Standalone.GiveKeys(playerId, vehicle, plate)
        elseif system ~= 'none' then error('Config.Keys invalide') end
        return true
    end)
    if not ok or result ~= true then report('Attribution des clés impossible : ' .. tostring(result)) return false end
    return true, system
end
function Bridge.RemoveKeys(playerId, vehicle, plate, system)
    local ok, reason = pcall(function()
        if system == 'qbox' and GetResourceState('qbx_vehiclekeys') == 'started' then exports['qbx_vehiclekeys']:RemoveKeys(playerId, vehicle, true)
        elseif system == 'qb' and GetResourceState('qb-vehiclekeys') == 'started' then exports['qb-vehiclekeys']:RemoveKeys(playerId, plate)
        elseif system == 'custom' then Standalone.RemoveKeys(playerId, vehicle, plate) end
    end)
    if not ok then report('Retrait des clés : ' .. tostring(reason)) end
end
