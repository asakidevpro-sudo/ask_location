-- À adapter à TON système d'argent. Aucun argent fictif n'est créé.
-- Ces fonctions doivent être synchrones (sans Wait), avec paiement atomique.
Standalone = {}
function Standalone.Balance(playerId)
    return nil, 'Configure le système d’argent dans server/standalone.lua.'
end
function Standalone.Charge(playerId, amount)
    -- Doit vérifier le solde et retirer le montant, puis renvoyer true.
    return false, 'Le paiement standalone n’est pas configuré.'
end

-- Facultatif : intégration de clés personnalisée avec Config.Keys = 'custom'.
function Standalone.GiveKeys(playerId, vehicle, plate)
    return false -- Remplacer par ton export de clés et renvoyer true si réussi.
end
function Standalone.RemoveKeys(playerId, vehicle, plate)
end
