local rentals, pending, cooldown = {}, {}, {}
local spawnBusy, monitoring, plateSequence = false, false, 0
local catalogCache = {}
local merchant = Config.RentalMerchant.coords
local serverDistance2 = Config.ServerDistance * Config.ServerDistance
local clearance2 = Config.SpawnClearance * Config.SpawnClearance
local function distanceSquared(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return dx * dx + dy * dy + dz * dz
end
-- Les offres ne changent pas en cours d'exécution : tri une seule fois au démarrage.
for _, id in ipairs(Config.VehicleOrder) do
    local definition = assert(Config.Vehicles[id], 'Véhicule absent : ' .. id)
    local offers = {}
    for minutes, price in pairs(definition.prices) do
        assert(type(minutes) == 'number' and minutes > 0 and minutes % 1 == 0, 'Durée invalide')
        assert(type(price) == 'number' and price > 0 and price % 1 == 0, 'Prix invalide')
        offers[#offers + 1] = { minutes = minutes, price = price }
    end
    table.sort(offers, function(a, b) return a.minutes < b.minutes end)
    catalogCache[#catalogCache + 1] = {
        id = id, label = definition.label, description = definition.description,
        enabled = definition.enabled and definition.model ~= '', offers = offers
    }
end
local function notify(playerId, message, kind)
    TriggerClientEvent('rental:notify', playerId, message, kind or 'error')
end
local function nearMerchant(playerId)
    local ped = GetPlayerPed(playerId)
    return ped ~= 0 and GetEntityHealth(ped) > 0 and GetPlayerRoutingBucket(playerId) == 0
        and distanceSquared(GetEntityCoords(ped), merchant) <= serverDistance2
end
local function limited(playerId)
    local now = GetGameTimer()
    if cooldown[playerId] and now - cooldown[playerId] < Config.Performance.requestCooldownMs then return true end
    cooldown[playerId] = now
    return false
end
local function cleanup(record, playerId)
    if not record then return end
    if record.keys then Bridge.RemoveKeys(playerId, record.entity, record.plate, record.keys) record.keys = nil end
    if record.entity and DoesEntityExist(record.entity) then DeleteEntity(record.entity) end
end
local function finish(playerId, message)
    local record = rentals[playerId]
    if not record then return end
    rentals[playerId] = nil
    cleanup(record, playerId)
    TriggerClientEvent('rental:ended', playerId)
    if message then notify(playerId, message, 'info') end
end
-- Pas de thread serveur permanent si aucune location n'est active.
local function startMonitor()
    if monitoring then return end
    monitoring = true
    CreateThread(function()
        while next(rentals) do
            Wait(math.max(250, Config.Performance.serverTickMs))
            local now, occupied = os.time(), nil
            for playerId, record in pairs(rentals) do
                if not DoesEntityExist(record.entity) then finish(playerId, 'Le véhicule a disparu. La location est terminée.')
                elseif now >= record.endsAt then
                    if not record.expired then
                        record.expired = true
                        notify(playerId, ('Location terminée. Gare-toi : retrait du véhicule sous %d secondes au maximum.'):format(Config.ExpiryGraceSeconds), 'warning')
                    end
                    if now >= record.endsAt + Config.ExpiryGraceSeconds then finish(playerId, 'Location terminée, véhicule retiré.')
                    else
                        -- Un seul parcours des PNJ par tick, uniquement pendant le délai de fin.
                        if not occupied then
                            occupied = {}
                            for _, ped in ipairs(GetAllPeds()) do
                                local vehicle = GetVehiclePedIsIn(ped, false)
                                if vehicle ~= 0 then occupied[vehicle] = true end
                            end
                        end
                        if not occupied[record.entity] then finish(playerId, 'Location terminée, véhicule retiré.') end
                    end
                elseif not record.warned and Config.WarningSeconds > 0 and record.endsAt - now <= Config.WarningSeconds then
                    record.warned = true
                    notify(playerId, 'Ta location se termine bientôt. Aucun retour au loueur nécessaire.', 'warning')
                end
            end
        end
        monitoring = false
    end)
end
RegisterNetEvent('rental:open', function()
    local playerId = source
    if limited(playerId) or not nearMerchant(playerId) then return end
    local balance, reason = Bridge.Balance(playerId)
    if balance == nil then notify(playerId, reason) return end
    TriggerClientEvent('rental:catalog', playerId, {
        title = Config.RentalMerchant.label, balance = balance, vehicles = catalogCache, active = rentals[playerId] ~= nil
    })
end)
RegisterNetEvent('rental:rent', function(vehicleId, minutes)
    local playerId = source
    if limited(playerId) then notify(playerId, 'Patiente un instant.') return end
    if not nearMerchant(playerId) then notify(playerId, 'Approche-toi du loueur.') return end
    if pending[playerId] or rentals[playerId] then notify(playerId, 'Tu as déjà une location en cours.') return end
    if type(vehicleId) ~= 'string' or type(minutes) ~= 'number' or minutes ~= minutes then return end
    local definition = Config.Vehicles[vehicleId]
    local price = definition and definition.prices[minutes]
    if not definition or not definition.enabled or definition.model == '' or not price then notify(playerId, 'Cette offre n’est pas disponible.') return end
    local balance, reason = Bridge.Balance(playerId)
    if balance == nil or balance < price then notify(playerId, reason or 'Tu n’as pas assez d’argent.') return end
    if spawnBusy then notify(playerId, 'Une location se prépare, réessaie dans un instant.') return end
    local spawn = definition.spawn or Config.Spawn
    -- Ce parcours ne se produit que sur une demande d'achat validée, jamais en boucle.
    for _, vehicle in ipairs(GetAllVehicles()) do
        if GetEntityRoutingBucket(vehicle) == 0 and distanceSquared(GetEntityCoords(vehicle), spawn) < clearance2 then
            notify(playerId, 'Libère le point de départ avant de louer.') return
        end
    end
    local token = { identity = Bridge.Identity(playerId) }
    if not token.identity then notify(playerId, 'Ton personnage n’est pas encore disponible.') return end
    pending[playerId], spawnBusy = token, true
    local ok, entity = pcall(CreateVehicleServerSetter, joaat(definition.model), definition.vehicleType, spawn.x, spawn.y, spawn.z, spawn.w)
    if not ok then print('[Location] Création du véhicule : ' .. tostring(entity)) entity = nil end
    token.entity = entity
    local deadline = GetGameTimer() + Config.SpawnTimeoutMs
    while pending[playerId] == token and entity and entity ~= 0 and not DoesEntityExist(entity) and GetGameTimer() < deadline do Wait(50) end
    if pending[playerId] ~= token or not nearMerchant(playerId) or Bridge.Identity(playerId) ~= token.identity then
        cleanup(token, playerId)
        if pending[playerId] == token then pending[playerId] = nil end
        spawnBusy = false
        return
    end
    if not entity or entity == 0 or not DoesEntityExist(entity) then
        cleanup(token, playerId)
        pending[playerId], spawnBusy = nil, false
        notify(playerId, 'Création impossible : aucun paiement effectué.') return
    end
    plateSequence = plateSequence + 1
    token.plate = ('L%07d'):format((os.time() + plateSequence) % 10000000)
    SetVehicleNumberPlateText(entity, token.plate)
    local keysOk, keys = Bridge.GiveKeys(playerId, entity, token.plate)
    if not keysOk then
        cleanup(token, playerId)
        pending[playerId], spawnBusy = nil, false
        notify(playerId, 'Le véhicule ne peut pas être préparé. Aucun paiement.') return
    end
    token.keys = keys
    local paid, paymentReason = Bridge.Charge(playerId, price)
    if not paid then
        cleanup(token, playerId)
        pending[playerId], spawnBusy = nil, false
        notify(playerId, paymentReason) return
    end
    SetEntityOrphanMode(entity, 2)
    token.endsAt = os.time() + minutes * 60
    rentals[playerId] = token
    pending[playerId], spawnBusy = nil, false
    TriggerClientEvent('rental:started', playerId, {
        netId = NetworkGetNetworkIdFromEntity(entity), seconds = minutes * 60, label = definition.label, plate = token.plate
    })
    notify(playerId, ('%s loué pour %d min : %d $. Aucun retour nécessaire.'):format(definition.label, minutes, price), 'success')
    startMonitor()
end)
AddEventHandler('playerDropped', function()
    local playerId = source
    cleanup(pending[playerId], playerId)
    pending[playerId], cooldown[playerId] = nil, nil
    finish(playerId)
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for playerId, record in pairs(rentals) do cleanup(record, playerId) end
    for playerId, record in pairs(pending) do cleanup(record, playerId) end
end)
