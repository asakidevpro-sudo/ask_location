local merchant, menuOpen, rental = nil, false, nil
local c = Config.RentalMerchant.coords
local merchantPosition = vector3(c.x, c.y, c.z) -- Calculé une fois, pas à chaque frame.
local interactDistance2 = Config.InteractDistance * Config.InteractDistance
local serverDistance2 = Config.ServerDistance * Config.ServerDistance
local farDistance2 = Config.Performance.farDistance * Config.Performance.farDistance
local function distanceSquared(position)
    local dx, dy, dz = position.x - c.x, position.y - c.y, position.z - c.z
    return dx * dx + dy * dy + dz * dz
end
local function closeMenu()
    if not menuOpen then return end
    menuOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end
local function notify(message, kind)
    SendNUIMessage({ action = 'notify', message = message, kind = kind,
        duration = Config.NotificationsDurationMs, label = Config.NotificationLabel })
end
RegisterNetEvent('rental:catalog', function(data)
    if source ~= 65535 then return end
    local ped = PlayerPedId()
    if IsEntityDead(ped) or distanceSquared(GetEntityCoords(ped)) > serverDistance2 then return end
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'catalog', data = data })
end)
RegisterNetEvent('rental:notify', function(message, kind)
    if source == 65535 then notify(message, kind) end
end)
-- La boucle existe seulement pendant une location ; le HUD reçoit au plus un message par seconde.
local function monitorRental(current)
    local wasVisible, lastSeconds = false, nil
    while rental == current do
        local visible = false
        if Config.Timer.enabled then
            if not Config.Timer.onlyInRentedVehicle then visible = true
            elseif NetworkDoesEntityExistWithNetworkId(current.netId) then
                local vehicle, ped = NetToVeh(current.netId), PlayerPedId()
                visible = vehicle ~= 0 and not IsEntityDead(ped) and GetVehiclePedIsIn(ped, false) == vehicle
            end
        end
        if visible then
            local seconds = math.max(0, math.ceil((current.endsAt - GetGameTimer()) / 1000))
            if not wasVisible or seconds ~= lastSeconds then
                SendNUIMessage({ action = 'timer', label = current.label, seconds = seconds })
                lastSeconds = seconds
            end
        elseif wasVisible then SendNUIMessage({ action = 'timer' }) lastSeconds = nil end
        wasVisible = visible
        Wait(math.max(50, Config.Timer.refreshMs))
    end
end
RegisterNetEvent('rental:started', function(data)
    if source ~= 65535 then return end
    closeMenu()
    local current = { netId = data.netId, label = data.label, endsAt = GetGameTimer() + data.seconds * 1000 }
    rental = current
    if Config.Timer.enabled then CreateThread(function() monitorRental(current) end) end
    CreateThread(function()
        local deadline = GetGameTimer() + Config.ModelTimeoutMs
        while rental == current and not NetworkDoesEntityExistWithNetworkId(data.netId) and GetGameTimer() < deadline do Wait(100) end
        if rental ~= current or not NetworkDoesEntityExistWithNetworkId(data.netId) then return end
        local vehicle = NetToVeh(data.netId)
        SetVehicleOnGroundProperly(vehicle)
        SetVehicleNumberPlateText(vehicle, data.plate)
        SetVehicleDoorsLocked(vehicle, 1)
        SetVehicleFuelLevel(vehicle, Config.Fuel.level)
        if Config.Fuel.resource ~= '' then
            local ok, reason = pcall(function() exports[Config.Fuel.resource][Config.Fuel.export](vehicle, Config.Fuel.level) end)
            if not ok then print('[Location] Adaptateur carburant : ' .. tostring(reason)) end
        end
    end)
end)
RegisterNetEvent('rental:ended', function()
    if source ~= 65535 then return end
    rental = nil
    SendNUIMessage({ action = 'timer' })
end)
RegisterNUICallback('close', function(_, cb) closeMenu() cb({ ok = true }) end)
RegisterNUICallback('rent', function(data, cb)
    if menuOpen and type(data.id) == 'string' and type(data.minutes) == 'number' then
        TriggerServerEvent('rental:rent', data.id, data.minutes)
    end
    cb({ ok = menuOpen })
end)
CreateThread(function()
    local model = joaat(Config.RentalMerchant.model)
    if not IsModelInCdimage(model) or not IsModelAPed(model) then print('[Location] Modèle PNJ invalide.') return end
    RequestModel(model)
    local deadline = GetGameTimer() + Config.ModelTimeoutMs
    while not HasModelLoaded(model) do
        if GetGameTimer() > deadline then print('[Location] Chargement du loueur impossible.') return end
        Wait(50)
    end
    merchant = CreatePed(4, model, merchantPosition.x, merchantPosition.y, merchantPosition.z - 1.0, c.w, false, false)
    SetEntityInvincible(merchant, true)
    FreezeEntityPosition(merchant, true)
    SetBlockingOfNonTemporaryEvents(merchant, true)
    SetModelAsNoLongerNeeded(model)
    while true do
        local ped = PlayerPedId()
        local distance2 = distanceSquared(GetEntityCoords(ped))
        local pause = distance2 > farDistance2 and Config.Performance.farWaitMs or Config.Performance.nearWaitMs
        if menuOpen then
            pause = Config.Performance.menuWaitMs
            if distance2 > serverDistance2 or IsEntityDead(ped) then closeMenu() end
        elseif distance2 <= interactDistance2 and not IsEntityDead(ped) then
            pause = 0 -- Le texte d'aide doit être dessiné à chaque frame, uniquement à proximité.
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(Config.InteractPrompt)
            EndTextCommandDisplayHelp(0, false, true, -1)
            if IsControlJustReleased(0, Config.InteractControl) then TriggerServerEvent('rental:open') end
        end
        Wait(pause)
    end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    rental = nil
    closeMenu()
    SendNUIMessage({ action = 'timer' })
    if merchant and DoesEntityExist(merchant) then DeleteEntity(merchant) end
end)
