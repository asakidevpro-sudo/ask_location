# Location de véhicules natifs

Trois choix configurables : BMX (`bmx`), Panto (`panto`) et Faggio (`faggio2`). Paiement au départ pour une durée choisie, sans retour obligatoire. Aucun modèle additionnel et aucun inventaire requis. Les écrans et notifications affichent uniquement des textes de location, sans marque technique.

## Installation

Activer OneSync. Démarrer ton framework puis le dossier de la ressource :

```cfg
ensure es_extended
ensure ask_location
```

Utiliser le nom réel du dossier dans la deuxième ligne. Pour QBCore, démarrer `qb-core` ; pour Qbox, `qbx_core`. Le code utilise `GetCurrentResourceName()` / `GetParentResourceName()` et fonctionne aussi si le dossier est renommé.

## Compatibilité du bridge

| Mode | Paiements |
| --- | --- |
| `esx` | ESX Legacy avec export `getSharedObject`, `getAccount` et `removeAccountMoney`. Compte `money` par défaut. |
| `qbcore` | QBCore avec export `GetCoreObject`, `GetMoney` et `RemoveMoney`. Compte `cash`. |
| `qbox` | Qbox via les exports natifs `GetPlayer`, `GetMoney` et `RemoveMoney`. Compte `cash`. |
| `standalone` | Adaptateur à compléter dans `server/standalone.lua` pour ton système personnel ou un autre framework. |
| `auto` | Détection des ressources démarrées. Qbox est prioritaire sur sa compatibilité QB. Si ESX et QB/Qbox coexistent, un choix explicite est exigé. |

Choisir `Config.Framework` et les comptes dans `Config.Accounts`. Une ressource de framework démarrée ou arrêtée invalide le cache du bridge ; la demande suivante tente une nouvelle initialisation. Un compte absent, un joueur non chargé ou un paiement refusé bloque la location. Les détails techniques restent dans la console serveur ; le joueur voit un message de service indisponible.

Tous les frameworks existants ne partagent pas les mêmes fonctions : vRP, des forks anciens ou des frameworks privés demandent leur propre adaptation. Le mode standalone ne donne pas de locations gratuites. Ses fonctions de paiement doivent être synchrones (sans Wait), vérifier le solde et débiter de façon atomique, puis renvoyer explicitement true en cas de succès.

### Clés et carburant

`Config.Keys = 'auto'` détecte `qbx_vehiclekeys`, puis `qb-vehiclekeys`. Les exports serveur GiveKeys/RemoveKeys sont utilisés ; les versions QB anciennes sans ces exports doivent être adaptées. L'attribution des clés se fait avant le débit : si elle échoue, le véhicule est supprimé sans paiement. Les clés sont retirées à la fin.

Modes : `none` pour un serveur sans script de clés ; `qb`, `qbox` pour un choix explicite ; `custom` pour compléter `Standalone.GiveKeys` / `Standalone.RemoveKeys`. Les clés et le carburant dépendent des ressources installées, pas uniquement du framework.

`Config.Fuel.level` règle le niveau initial. `Config.Fuel.resource = ''` utilise le carburant natif. Pour un export compatible, renseigner le nom de la ressource et de son export SetFuel. Les systèmes utilisant une autre API demandent un adaptateur.

## Configuration

| Véhicule | 30 min | 60 min |
| --- | --- | --- |
| BMX | 500 $ | 1 000 $ |
| Panto | 300 $ | 600 $ |
| Faggio | 750 $ | 1 500 $ |

Dans `Config.Vehicles`, modifier le modèle natif, son type, le nom affiché, la description, l'activation, les prix et le spawn :

```lua
panto = {
    spawn = vector4(-1030.20, -2730.30, 20.15, 240.0),
    label = 'Panto', model = 'panto', vehicleType = 'automobile', enabled = true,
    description = 'Une petite citadine.',
    prices = { [30] = 300, [60] = 600 }
}
```

`vector4` contient X, Y, Z et le cap en degrés. `spawn = nil` utilise le point commun `Config.Spawn`. Le serveur vérifie que le point est libre. `Config.VehicleOrder` règle l'ordre des choix. Le premier loueur de `Config.Merchant[1]` est utilisé ; cette version ne crée pas plusieurs points de location.

`[30] = 300` signifie 30 minutes pour 300 $. Ajouter `[15] = 200` crée une nouvelle offre. Redémarrer la ressource après un changement de configuration : le catalogue est mis en cache au démarrage.

`Config.NotificationLabel` règle le titre des notifications. `Config.Timer` règle le compteur (activation, visibilité dans le véhicule loué uniquement et intervalle de vérification). Le compteur est en haut au centre et disparaît à la descente. Le temps continue à s'écouler à pied ; les notifications se positionnent sous le compteur.

## Optimisations apportées

- Client sans location : aucune boucle de compteur. Contrôles de proximité toutes les 1 000 ms loin du PNJ, 250 ms à proximité et 200 ms quand le menu est ouvert. Dessin par frame uniquement à portée de la touche d'interaction.
- Location active : vérification du véhicule toutes les 200 ms par défaut. Message au HUD uniquement si la seconde ou la visibilité change.
- Serveur sans location : aucun thread périodique de surveillance. Un seul thread est créé à la première location et se termine après la dernière.
- Catalogue et tri des offres calculés une seule fois. Distances comparées au carré pour éviter les racines carrées et les constructions de vecteurs dans les boucles.
- GetAllPeds : uniquement pendant le délai de fin, au plus une fois par tick pour toutes les locations. Aucun parcours quand la suppression est forcée.
- GetAllVehicles : uniquement lors d'une demande de location préalablement validée, pour éviter une apparition sur un véhicule existant.
- NUI sans intervalle permanent. Références DOM et format monétaire en cache ; cartes assemblées dans un fragment ; mesure de taille du compteur uniquement lors de changements de visibilité/nom ou redimensionnement.

Les intervalles sont dans `Config.Performance`. Le contrôle local du compteur utilise `Config.Timer.refreshMs`. Une valeur très faible augmente la charge. Aucun chiffre en ms de resmon n'est garanti : les performances doivent être mesurées dans FiveM avec la population et les autres ressources réelles.

## Pédagogie : ne travailler que quand nécessaire

```lua
if monitoring then return end
monitoring = true
```

Ces deux lignes évitent de lancer un deuxième surveillant quand un joueur loue un véhicule. Une seule boucle s'occupe de toutes les locations. Quand il n'y a plus de location, la boucle se termine. Le même principe s'applique au compteur côté joueur.

## Limites et tests en jeu

Une location par joueur ; le serveur contrôle prix, durée, proximité, solde et identité du personnage après le chargement. À expiration, suppression quand le véhicule est vide ou après `Config.ExpiryGraceSeconds`. Déconnexion, disparition du véhicule et arrêt de ressource : annulation sans remboursement automatique. Pas de sauvegarde en base de données.

Les changements sont vérifiés par compilation Lua via MoonSharp (syntaxe compatible Lua 5.2), tests avec natives/frameworks simulés et tests JavaScript avec DOM simulé. Cela ne remplace pas l'exécution dans le runtime Lua 5.4 de FiveM ni les tests des exports installés sur le serveur.

À vérifier sur chaque serveur : paiement et solde, clés et moteur, carburant, trois modèles natifs, spawn occupé, demande distante, seconde location refusée, compteur à la descente/remontée, expiration, déconnexion et arrêt de ressource.

Pour mesurer, utiliser `resmon 1` côté client (si disponible dans le mode de développement FiveM) et le profiler pour les traitements client/serveur. Comparer loin du PNJ sans location, près du PNJ, en location et lors de plusieurs expirations. Aucun benchmark en jeu n'a été effectué ici.

Références : [Qbox paiements](https://docs.qbox.re/resources/qbx_core/exports/server), [Qbox clés](https://docs.qbox.re/resources/qbx_vehiclekeys/exports/server), [QBCore](https://qbcore.org/docs/qb-core/player-data), [clés QB](https://github.com/qbcore-framework/qb-vehiclekeys), [profiler FiveM](https://docs.fivem.net/docs/scripting-manual/debugging/using-profiler/).
