const menu = document.querySelector('#menu');
const timerElement = document.querySelector('#timer');
const notifications = document.querySelector('#notifications');
const rentalLabel = document.querySelector('#rental-label');
const remaining = document.querySelector('#remaining');
const title = document.querySelector('#title');
const balance = document.querySelector('#balance');
const vehicles = document.querySelector('#vehicles');
const currencyFormatter = new Intl.NumberFormat('fr-FR');
// Décaler les notifications sous le compteur pour éviter leur superposition.
function updateNotificationPosition() {
    const offset = timerElement.hidden ? 0 : timerElement.getBoundingClientRect().height + 8;
    document.documentElement.style.setProperty('--notification-offset', `${offset}px`);
}
window.addEventListener('resize', updateNotificationPosition);
const inGame = typeof GetParentResourceName === 'function';
const money = value => currencyFormatter.format(Number(value)) + ' $';
let sending = false;
async function post(route, data = {}) {
    if (!inGame) return;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
        const response = await fetch(`https://${GetParentResourceName()}/${route}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data), signal: controller.signal
        });
        if (!response.ok) throw new Error('Interface indisponible.');
        return await response.json();
    } finally { clearTimeout(timeout); }
}
function notify(message, kind = 'info', duration = 5000, notificationLabel = 'LOCATION') {
    const node = document.createElement('div');
    node.className = `notification ${['success', 'error', 'warning', 'info'].includes(kind) ? kind : 'info'}`;
    const icon = document.createElement('span');
    icon.className = 'icon';
    icon.textContent = kind === 'success' ? '✓' : '!';
    const content = document.createElement('div');
    const label = document.createElement('span');
    label.className = 'label'; label.textContent = notificationLabel;
    const text = document.createElement('p'); text.textContent = message;
    content.append(label, text); node.append(icon, content);
    const container = notifications;
    if (container.children.length >= 4) container.firstElementChild.remove();
    node.style.setProperty('--duration', String(duration) + 'ms');
    container.append(node); setTimeout(() => node.remove(), duration);
}
function render(data) {
    menu.hidden = false;
    title.textContent = data.title;
    balance.textContent = money(data.balance);
    const list = document.createDocumentFragment();
    for (const vehicle of data.vehicles) {
        const card = document.createElement('article'); card.className = 'vehicle';
        const title = document.createElement('h2'); title.textContent = vehicle.label;
        const description = document.createElement('p'); description.textContent = vehicle.description;
        const offers = document.createElement('div'); offers.className = 'offers';
        for (const offer of vehicle.offers) {
            const button = document.createElement('button'); button.className = 'offer';
            const duration = document.createElement('span'); duration.textContent = `${offer.minutes} min`;
            const price = document.createElement('strong'); price.textContent = money(offer.price);
            button.append(duration, price);
            button.disabled = !vehicle.enabled || data.active || data.balance < offer.price;
            button.setAttribute('aria-label', `Louer ${vehicle.label} : ${offer.minutes} minutes, ${offer.price} dollars`);
            button.addEventListener('click', async () => {
                if (sending) return;
                if (!inGame) { notify('Aperçu : les locations fonctionnent dans FiveM.'); return; }
                sending = true;
                try { await post('rent', { id: vehicle.id, minutes: offer.minutes }); }
                catch { notify('Impossible de contacter le jeu. Réessaie.', 'error'); }
                finally { setTimeout(() => { sending = false; }, 1000); }
            });
            offers.append(button);
        }
        card.append(title, description, offers);
        if (!vehicle.enabled || data.active) {
            const status = document.createElement('p'); status.className = 'unavailable';
            status.textContent = !vehicle.enabled ? 'Bientôt disponible' : 'Une location est déjà en cours';
            card.append(status);
        }
        list.append(card);
    }
    vehicles.replaceChildren(list);
}
async function close() {
    try { await post('close'); menu.hidden = true; }
    catch { notify('Impossible de fermer le menu. Réessaie.', 'error'); }
}
document.querySelector('#close').addEventListener('click', close);
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !menu.hidden) close(); });
window.addEventListener('message', ({ data }) => {
    if (data.action === 'catalog') render(data.data);
    if (data.action === 'close') menu.hidden = true;
    if (data.action === 'notify') notify(data.message, data.kind, data.duration, data.label);
    if (data.action === 'timer') {
        const wasHidden = timerElement.hidden;
        timerElement.hidden = typeof data.seconds !== 'number';
        let labelChanged = false;
        if (!timerElement.hidden) {
            labelChanged = rentalLabel.textContent !== data.label;
            if (labelChanged) rentalLabel.textContent = data.label;
            const text = data.seconds > 0
                ? `${Math.floor(data.seconds / 60)}:${String(data.seconds % 60).padStart(2, '0')}` : 'Terminée';
            if (remaining.textContent !== text) remaining.textContent = text;
        }
        // Mesurer le panneau uniquement s'il apparaît, disparaît ou change de nom.
        if (wasHidden !== timerElement.hidden || labelChanged) updateNotificationPosition();
    }
});
// Aperçu autonome de l'interface, sans argent ni véhicule réel.
if (!inGame) render({ title: 'Location de véhicules', balance: 1500, active: false, vehicles: [
    { id: 'bmx', label: 'BMX', description: 'Un vélo agile pour explorer la ville.', enabled: true, offers: [{ minutes: 30, price: 500 }, { minutes: 60, price: 1000 }] },
    { id: 'panto', label: 'Panto', description: 'Une petite citadine pratique pour tes déplacements.', enabled: true, offers: [{ minutes: 30, price: 300 }, { minutes: 60, price: 600 }] },
    { id: 'faggio', label: 'Faggio', description: 'Un scooter pour circuler tranquillement en ville.', enabled: true, offers: [{ minutes: 30, price: 750 }, { minutes: 60, price: 1500 }] },
] });
